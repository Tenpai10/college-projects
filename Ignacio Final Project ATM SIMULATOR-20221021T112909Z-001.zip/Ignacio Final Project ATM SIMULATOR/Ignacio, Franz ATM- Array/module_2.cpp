/*Ignacio, Franz Arvae
BS-IT 2C */

#include<iostream>
#include<string>
#include<windows.h>
#include<conio.h>
#include<fstream>
#include<stdlib.h>
#include<string.h>

#define MAX 50
#define MAX_LENGTH 50
#define PASS_LENGTH 6
using namespace std;

typedef struct account{
    string lock_acc;
}ACC;

ACC acc[MAX];

typedef struct userInfo{

    char account_number[MAX_LENGTH];
    char password[PASS_LENGTH];
    int balance;
    char decr_pass[PASS_LENGTH];

}uInfo;

uInfo info;

typedef struct variables{

    int flag;
    int checker;
    int error;
    int amount;
    int charge_exception;
    string holder;
    string file_path;
    int last;

}VAR;

VAR var;

void make_null();
void retrieve();
void add_lock_account();
void save_lock_account();

int locate_path();
void card_queue(int);
void decrypt_pass();
int display_menu();
int check_password();
void main_menu();
int check_entry();
void withdraw(int);
int check_balance();
void numeric_only(int);
void update();
int locate_account(char*);
void bal_inq();
void fund_transfer(int);
void change_password();
void pay_bills();

int main(){

    make_null();
    retrieve();
    while(1){
        card_queue(0);
        decrypt_pass();
//        if(display_menu()){
//            main_menu();
//            update();
//        }
        card_queue(1);
        add_lock_account();
        save_lock_account();
    }

return 0;
}

void make_null(){
var.last = -1;
var.flag = 0;
}

int locate_path(){

    var.checker = 1;
    char drive;

    for(drive = 'D';drive<'I';drive++){
        var.file_path = drive;
        var.file_path += ":\\data.txt";

        ifstream inFile(var.file_path);
        if(inFile){
            var.checker = 0;
            inFile.close();
            break;
        }
        inFile.close();
    }

    if(var.checker == 0){
        ifstream inFile(var.file_path);
        inFile >> info.account_number >> info.password >> info.balance;
        inFile.close();
        return var.checker;
    }else{
        return var.checker;
    }
}

void card_queue(int flag){

    var.error = 0;
    var.amount = 0;

    if(flag == 0) {
        while(locate_path()){
            system("cls");
            if(flag == 1){
                break;
            }else{
                Sleep(1000);
                cout << "\n\n\n\n\n\n\t\t\t\t[Please insert ATM card]";
                Sleep(1000);
            }
        }
    }
        char line[MAX_LENGTH];
        ifstream inFile("Locked Accounts.txt");

        while(inFile >> line){
            if(strcmp(info.account_number,line)==0){
                system("cls");
                cout << "\n\n\t\tWarning: Due to multiple attempts, your account is temporarily locked" << endl;
                cout << "\t\tContact Bank Administration: Hotline 201-6969" << endl;
                Sleep(3000);
                flag = 1;
                card_queue(0);
                break;
            }
        }
        inFile.close();

    if(flag == 1){
        while(!locate_path()){
            system("cls");
            Sleep(1000);
            cout << "\n\n\n\n\n\n\t\t\t[Please wait for the card to eject]";
            Sleep(1000);
        }
    }
}

void decrypt_pass(){
    for(int i=0; i < PASS_LENGTH; i++){
        info.decr_pass[i] = info.password[i] - 30;
    }
}

int display_menu(){

    while(var.error < 3){
        system("cls");
        cout << "\n\n\n\n\t\t\t\t[BANKERU BANK]"<< endl;
        int flag = check_password();
        if(flag == 0){
            char filePath [50] = "Fund Transfer Queue\\";
            strcat(filePath,info.account_number);
            strcat(filePath,".txt");

            ifstream inFile(filePath);
            if(inFile){
                inFile >> var.amount;
                info.balance += var.amount;
                Sleep(1000);
                system("cls");
                cout << "\n\n\t\tNotice: You've received funds" << endl;
                Sleep(2000);
            }
            inFile.close();
            remove(filePath);

            return 1;
        }
    }
    if (var.error == 3){
        return 0;
    }

}

int check_password(){
    cout << "\n\n\t\t\tInput your 6-digit password: ";

    string pin;
    char holder;

    int i = 0;
    while(i<6){
        holder = getch();
        if(holder==8 && i>=0){
            cout << "\b \b";
            pin.pop_back();
            i--;
        }else{
            if(isdigit(holder)){
                putch('*');
                pin += holder;
                i++;
            }else{
                i--;
            }
        }
    }

    if(strcmp(info.decr_pass,pin.c_str()) == 0){
        return 0;
    }else{
        cout << "\n\n\t\t\tWrong pin bobo";
        getch();
        var.error++;

        if(var.error == 3){
            cout << "\n\n\t\t\tWarning: Multiple Attempts..." << endl;
            Sleep(1000);
            var.flag += 3;
        }

        return 1;

    }
}

void main_menu(){
    var.error = 0;
    system("cls");
    char choice;
    cout << "\n\n\t\t\t\tWelcome to Banktotan\n\n " << endl;
    cout << "\t\t[1] Withdraw\t\t\t\t[5] Pay Bills"  << endl;
    cout << "\t\t[2] Balance Inquiry\t\t\t[6] Deposit"  << endl;
    cout << "\t\t[3] Fund transfer\t\t\t[7] Cancel Transaction" << endl;
    cout << "\t\t[4] Change Pin\t\t\t\t[8] Fast Cash" << endl;

    cout << "\n\n\t\t\t\t\tOption: ";

    switch(check_entry()){

        case 1: system("cls");
                if(info.balance > 100){
                    var.amount = 0;
                    var.charge_exception = 0;
                    withdraw(0);
                }else{
                    cout << "\n\t\tNot enough balance" << endl;
                    var.charge_exception = 1;
                }
                getch();break;

        case 2: system("cls");
                while(1){
                    bal_inq();
                    cout << "\n\n\t\t[1] New Transaction \t\t[2] Cancel Transaction\n\n\t\tOption:";
                    var.checker = check_entry();
                    if(var.checker == 1){
                        main_menu();
                        break;
                    }else if(var.checker == 2){
                        var.charge_exception = 0;
                        break;
                    }
                }
                break;

        case 3: system("cls");
                if(info.balance <= 500){
                    cout << "\n\n\t\tNot enough funds";
                    var.charge_exception = 1;
                }else if(locate_account(info.account_number)){
                    cout << "\n\n\t\tAccount not verified";getch();
                    main_menu();
                }else{
                    var.charge_exception = 0;
                    fund_transfer(1);
                }
                getch();break;

        case 4: system("cls");
                if(locate_account(info.account_number)){
                    cout << "\n\n\t\tAccount not verified";getch();
                    main_menu();
                }else{
                    var.error = 0;
                    var.charge_exception = 0;
                    change_password();
                }
                getch();break;

        case 5: system("cls");
                if(info.balance>=600){
                    var.charge_exception = 0;
                    pay_bills();
                }else{
                    cout << "\n\t\tNot enough funds..." << endl;
                    var.charge_exception = 1;
                }
                getch();break;

        case 6: system("cls");
            if(locate_account(info.account_number)){
                cout << "\n\n\t\tAccount not verified";getch();
                main_menu();
            }else{
                fund_transfer(0);
            }
                getch();break;

        case 7: system("cls");
                cout << "\n\n\t\tTransaction Cancelled..." << endl;
                var.charge_exception = 1;
                getch();break;

        case 8: system("cls");
                var.amount = 0;
                if(info.balance>600){
                    while(1){
                        system("cls");
                        cout << "\n\n\n\t\tWithdraw\n\t\t[1] P500\t\t[4] P5,000\n\t\t[2] P1,000\t\t[5] P10,000\n\t\t[3] P3,000\t\t[6] Cancel Transaction" << endl;
                        cout << "\n\t\tOption: ";
                        var.checker = check_entry();
                        if(var.checker<6 && var.checker>0){
                            int amount[5] = {500, 1000, 3000, 5000, 10000};
                            var.amount = amount[var.checker-1];
                            if(!check_balance()){
                                info.balance -= var.amount;
                                cout << "\n\n\t\tSuccessfully withdrawn P" << var.amount << " from your account..." << endl;
                                cout << "\t\tCurrent balance: P" << info.balance << endl;
                                var.charge_exception = 0;
                                break;
                            }
                        }else if(var.checker == 6){
                            var.charge_exception = 1;
                            break;
                        }
                    }
                }else{
                    cout << "\n\n\t\tNot enough funds...";
                    var.charge_exception = 1;
                }
                getch();break;

        default:system("cls");
                cout << "\n\n\t\tInvalid Option";
                Sleep(2000);
                main_menu();
                getch();break;
    }

    if(locate_account(info.account_number) > 0 && var.charge_exception != 1){
        info.balance -= 15;
        cout << "\n\t\tTransaction charged" << endl;
        getch();
    }
}

int check_entry(){

    char holder;
    int i = 0;
    while(i<1){
        holder = getch();
        if(isdigit(holder)){
            for(int j = 48; j <= 57; j++){
                if(holder == j){
                    j -= 48;
                    return j;
                }
            }
            return 0;
        }else{
            i--;
        }
    }

}

void withdraw(int withdraw_amount){

    withdraw_amount;
    system("cls");
    cout << "\n\n\t\tWithdraw Amount: P" << withdraw_amount << endl;
    cout << "\t\tInput amount: ";
    numeric_only(0);
    var.checker = check_balance();
    if(var.checker == 0){

        withdraw_amount += var.amount;
        cout << "\n\n\t\t[1] Withdraw\t\t[3] Cancel Transaction \n\t\t[2] Add Withdrawal Amount\n\t\tInput option: ";
        int opt = check_entry();
        switch(opt){
        case 1:system("cls");
            info.balance -= withdraw_amount;
            cout << "\n\n\t\tAmount: P" << withdraw_amount << " is successfully withdrawn!" << endl;
            Sleep(1500);
            break;
        case 2:system("cls");
            withdraw(withdraw_amount);
            break;
        case 3:system("cls");
            cout << "\t\tThank you for using Banktotan!" << endl;
            Sleep(1500);
            break;
        }
    }

}

int check_balance(){

    if(var.amount < info.balance && info.balance - var.amount > 100){
        if(var.amount % 100 != 0 && var.amount != 0){
            cout << "\n\t\tNotice: Machine only accepts/gives 100 pesos and higher bills... gomenasai" << endl;
            var.charge_exception = 1;
            getch();
            return 1;
        }
        return 0;

    }else{
        cout << "\n\t\tNot enough funds on your account..." << endl;
        cout << "\t\tMaintaining Balance should not be less than P100" << endl;
        var.charge_exception = 1;
        getch();
        return 1;
    }
}

void numeric_only(int flag){
    string amount;
    char holder;

    int i = 0;
    while(i<6){
        holder = getch();
        if(holder==8 && i>=0){
            cout << "\b \b";
            amount.pop_back();
            i--;
        }else if(holder==13){
            break;
        }else{
            if(isdigit(holder)){
                if(flag==0){putch(holder);}
                else{putch('*');}
                amount += holder;
                i++;
            }else{
                i--;
            }
        }
    }
    var.holder = amount;
    var.amount = atoi(amount.c_str());
}

void update(){
    int newBalance = info.balance;
    ofstream outFile(var.file_path);
    info.password[PASS_LENGTH] = '\0';
    outFile << info.account_number << " " << info.password << " " << newBalance;
    outFile.close();
}

int locate_account(char searchFile[MAX_LENGTH]){

    char line[MAX_LENGTH];
    int i = 0;
    ifstream inFile("List of Accounts.txt");
    while(inFile >> line){
        if(strcmp(searchFile, line) == 0){
            return 0;
        }else{
            i++;
        }
    }
    return i;
}

void bal_inq(){
    cout << "\n\n\t\tAccount number: " << info.account_number << endl;
    cout << "\t\tCurrent balance: P" << info.balance << endl;
}

void fund_transfer(int flag){

    var.amount = 0;
    int max_amount;
    char loc_account[MAX_LENGTH];
    if(flag == 1){
        while(flag){
            system("cls");
            cout << "\n\n\t\tAccount number: ";
            cin.getline(loc_account,MAX_LENGTH);

            if(strcmp(loc_account,info.account_number)!=0){
                max_amount = 20000;
                break;
                if(locate_account(loc_account)){
                    cout << "\t\tBank account not existing..." << endl;
                    main_menu();
                }
            }else{
                cout << "\t\tNotice: You are using your own account number" << endl;
                Sleep(1500);
            }
        }
    }else if(flag == 0){
        strcpy(loc_account,info.account_number);
        max_amount = 10000;
    }

    int amount = 0;

        while(var.amount < 500 || var.amount > max_amount){
            system("cls");
            cout << "\n\n\t\tInput amount of fund to transfer on Account number: " << loc_account << endl;
            cout << "\t\tAmount [minimum of P500 || maximum of P" << max_amount << "]:";
            numeric_only(0);

            if(var.amount >= 500 && var.amount <= max_amount){
                if (flag == 0 && var.amount>=500 && var.amount<=max_amount){
                    check_password();
                    info.balance+=var.amount;
                    cout << "\n\t\t\tDeposit successfull" << endl;
                    cout << "\t\tAmount: " << var.amount << endl;
                    cout << "\t\tNew Balance: " << info.balance << endl;
                    break;

                }else if(check_balance()){
                    cout << "\n\t\tCannot transfer funds..." << endl;
                    Sleep(1500);
                    var.amount = 0;

                }else if(flag == 1){

                    check_password();
                    char filePath [50] = "Fund Transfer Queue\\";
                    strcat(filePath,loc_account);
                    strcat(filePath,".txt");

                    int queue_amount = 0;
                    ifstream inFile(filePath);
                    inFile >> queue_amount;
                    inFile.close();

                    queue_amount+=amount;
                    ofstream outFile(filePath);
                    outFile << queue_amount << endl;
                    outFile.close();

                    info.balance -= var.amount;
                    cout << "\n\n\t\tFund successfully transferred to " << loc_account << endl;
                    cout << "\t\tAmount: P" << var.amount << endl;
                }
            }else{
                cout << "\n\n\t\tInvalid input" << endl;
            }
        }
}

void change_password(){
    system("cls");
    if(var.error < 3){
        string temp, temp2;
        if(!check_password()){
            while(1){
                system("cls");
                cout << "\n\n\t\tNew 6-digit pin code: ";
                numeric_only(1);
                temp = var.holder;
                cout << "\n\t\tRe-enter 6-digit pin code: ";
                numeric_only(1);
                temp2 = var.holder;
                if(temp == temp2){
                    break;
                }else{
                    cout << "\n\n\t\tInvalid input..." << endl;
                    getch();
                }
            }
            for(int i=0;i<6;i++){
                info.password[i] = temp[i] + 30;
            }
            cout << "\n\n\t\tYou've successfully changed your pin-code!" << endl;
            getch();
        }else{
            change_password();
        }
    }
}

void pay_bills(){
    cout << "\n\n\t\tPayment Menu: \n" << endl;
    cout << "\t\t[1] Meralco" << endl;
    cout << "\t\t[2] Maynilad" << endl;
    cout << "\t\t[3] LTFRBQ+" << endl;
    cout << "\t\t[4] Corn-hub Premium" << endl;
    cout << "\t\t[5] Cancel Transaction" << endl;
    cout << "\n\t\tOption: ";
    var.checker = check_entry();
    if(var.checker >= 5 || var.checker < 1){
        cout << "\n\t\tTransaction Cancelled";
        var.charge_exception = 1;
    }else{
    info.balance -= 500;
    cout << "\n\t\tPayment Successful!" << endl;
    }
}

void retrieve_accounts(){
    ifstream inFile("Locked accounts.txt");
    cout << "Locked:" << endl;
    int i = 0;
    while(inFile >> acc[i].lock_acc){
        cout << acc[i].lock_acc << endl;
        i++;
    }
    var.last = i;
    getch();
}

void add_lock_account(){
    var.flag += var.error;
    if(var.flag == 6){
        var.last++;
        acc[var.last].lock_acc = info.account_number;
        cout << "Locked: " << acc[var.last].lock_acc;getch();
        var.error = 0;
        var.flag = 0;
    }
}

void save_lock_account(){
    remove("Locked accounts.txt");
    for(int i=0;i<var.last+1;i++){
        ofstream outFile("Locked Accounts.txt",fstream::app);
        outFile << acc[i].lock_acc << endl;
        outFile.close();
    }
}

