/*Ignacio, Franz
BS-IT 2C*/

#include<iostream>
#include<conio.h>
#include<windows.h>
#include<fstream>
#include<time.h>
#include<string.h>

#define MAX 100

using namespace std;

typedef struct info{

    string first_name;
    string last_name;
    string contact_num;
    string address;
    string birthday;
    string email;
    string age;

    string account_number;
    string pin;
    int balance;

    string profile[8];

}INFO;

INFO info[MAX];

void makeNull();
void add_account();
void deactivate();
void display();
void save();
void retrieve();
int isFull();
int isEmpty();
int menu();
int locate_path();
void encrypt();
void edit_info();

int last;

int main(){

    //initialize, gawin mong -1 yung last value since sa zero is the first index sa array
    makeNull();
    //retrieve registered accounts
    retrieve();
    //while 1 is also while true, looping to hangga't hindi nag bbreak, di titigil
    while(1){
        //basic menu system, ibabalik nung function menu() yung value na pnili mo.
        switch(menu()){

        case 1:system("cls");
            add_account();
            getch();break;
        case 2:system("cls");
            deactivate();
            getch();break;
        case 3:system("cls");
            edit_info();
            getch();break;
        case 4:system("cls");
            display();
            getch();break;
        case 5:system("cls");
            save();
            getch();exit(0);break;
        default:break;
        }
    }

return 0;
}

void makeNull(){last = -1;}
int isFull(){return last==MAX-1;}
int isEmpty(){return last<0;}

void retrieve(){
    string line;
    int i = 0;
    //dapat may List of accounts ka na holder/txt file, parang cluster to sa database
    //Master list mo to ng lahat ng existing accounts
    ifstream inFile("List of accounts.txt");
    while(inFile >> line){
        last++;
        info[last].account_number = line;

        //chcheck sa folder customers yung customer information
        string file_name = "Customers\\" + line + ".txt";
        //eto na yung mismong retrieve pre
        FILE * fp;
        fp = fopen(file_name.c_str(),"r");
        char dummy[7][50];
        int j = 0;
        while(!feof(fp)){
            //scan string with spaces yang data type na yan
            fscanf(fp, "%[^\n]\n", dummy[j]);
            j++;
        }
        fclose(fp);

        //insert to cache array
        info[last].last_name = dummy[0];
        info[last].first_name = dummy[1];
        info[last].age = dummy[2];
        info[last].birthday = dummy[3];
        info[last].address = dummy[4];
        info[last].contact_num = dummy[5];
        info[last].email = dummy[6];

        i++;
    }
    inFile.close();

}

int menu(){

    system("cls");
    int opt;
    cout << "\n\t\tBankeru: " << endl;
    cout << "\t\t[1] Add Account" << endl;
    cout << "\t\t[2] Deactivate Account" << endl;
    cout << "\t\t[3] Edit Database" << endl;
    cout << "\t\t[4] Display Accounts" << endl;
    cout << "\t\t[5] Exit" << endl;
    cout << "\n\t\tOption: ";
    cin >>  opt;
    return opt;
}

void edit_info(){
    system("cls");
    display();
    int opt, pos;
    cout << "\n\t\tInput num you want to edit: ";
    cin >> opt;

    pos = opt - 1;
    if(pos > last || pos < 0){
        edit_info();
    }else{
        int choice;
        system("cls");
        string dummy[8];
        dummy[0] = info[pos].account_number;
        dummy[1] = info[pos].last_name;
        dummy[2] = info[pos].first_name;
        dummy[3] = info[pos].age;
        dummy[4] = info[pos].birthday;
        dummy[5] = info[pos].address;
        dummy[6] = info[pos].contact_num;
        dummy[7] = info[pos].email;

        cout << "\n\t\tInformation: \n" << endl;
        cout << "\t\tAccount No.: " << dummy[0] << endl;
        cout << "\t\t[1] Last Name: " << dummy[1] << endl;
        cout << "\t\t[2] First Name: " << dummy[2] << endl;
        cout << "\t\t[3] Age: " << dummy[3] << endl;
        cout << "\t\t[4] Birthday: " << dummy[4] << endl;
        cout << "\t\t[5] Address: " << dummy[5] << endl;
        cout << "\t\t[6] Contact Number: " << dummy[6] << endl;
        cout << "\t\t[7] E-mail: " << dummy[7] << endl;
        cout << "\n\t\t[EDIT] option:";
        cin >> choice;

        if(choice>7||choice<1){
            edit_info();
        }else{
            string line;
            cout << "\n\t\t [" << choice << "] Replace with: ";
            getline(cin>>ws,line);

            dummy[choice] = line;

            info[pos].account_number = dummy[0];
            info[pos].last_name = dummy[1];
            info[pos].first_name = dummy[2];
            info[pos].age = dummy[3];
            info[pos].birthday = dummy[4];
            info[pos].address = dummy[5];
            info[pos].contact_num = dummy[6];
            info[pos].email = dummy[7];

        }
    }
}

void add_account(){
    cout << last;getch();
    if(isFull()){
        cout << "\n\t\tList is Full!" << endl;
    }else{
        last++;
        cout << "\n\t\tAdd-Account: "<<endl;
        cout << "\t\tFirst Name: ";
        getline(cin>>ws, info[last].first_name);
        cout << "\t\tLast Name: ";
        getline(cin>>ws, info[last].last_name);
        cout << "\t\tAge: ";
        getline(cin>>ws, info[last].age);
        cout << "\t\tBirthday: ";
        getline(cin>>ws, info[last].birthday);
        cout << "\t\tAddress: ";
        getline(cin>>ws, info[last].address);
        cout << "\t\tContact Number: ";
        getline(cin>>ws, info[last].contact_num);
        cout << "\t\tE-mail: ";
        getline(cin>>ws, info[last].email);

        int balance;
        do{
            system("cls");
            cout << "\n\t\tDeposit: ";
            cin >> balance;
        }while(balance < 500 || balance > 20000 || balance % 100 != 0);
        info[last].balance = balance;

        srand(time(NULL));
        int i = 0;
        string code;
        while(i<4){
            code += to_string((rand() % 9) + 1);
            i++;
        }
        string account_id = "Bankeru-" + to_string(6900 + last) + "-" + code;
        cout << "\n\t\tAccount Number: " << account_id << endl;getch();
        i = 0;
        info[last].account_number = account_id;

        string pin;
        while(i<6){
            pin += to_string((rand() % 9) + 1);
            i++;
        }
        cout << "\t\tYour temporary pin: " << pin << endl;getch();
        info[last].pin = pin;
        encrypt();

        system("cls");
        while(locate_path()){
            cout << "\n\n\t\tPlease insert your ATM-card to register..." << endl;
            Sleep(1500);
            system("cls");
        }

        cout << "\n\t\tRegistered Successfully!" << endl;
    }
}

int locate_path(){

    for(char i = 'D'; i <= 'H'; i++){
        string file = ":\\data.txt";
        string file_path = i + file;
            fstream database(file_path, fstream::in | fstream::out);
            if(database){
                database << info[last].account_number << " " << info[last].pin << " " << info[last].balance;
                database.close();
                return 0;
            }
            database.close();
    }
    return 1;
}

void encrypt(){
    for(int i=0; i<6; i++){
        info[last].pin[i] += 30;
    }
}

void deactivate(){

    if(!isEmpty()){
        system("cls");
        display();
        int pos;
        cout << "\n\t\tInput number you want to deactivate: ";
        cin >> pos;
        cout << last;getch();
        if(pos-1>last || pos-1<1){
            deactivate();
        }else{
            int flag = 0;
            ifstream file("Locked accounts.txt");
                string line;

                while(file >> line){
                    if(line == info[pos-1].account_number){

                        cout << "\n\t\tAccount is already deactivated" << endl;
                        flag = 1;break;
                    }
                }
            file.close();

            if(flag == 0){
                cout << "\n\t\tAccount: " << info[pos-1].account_number << " is Successfully Deactivated!";

                ofstream deactivate("Locked accounts.txt",ios::app);
                deactivate << info[pos-1].account_number <<endl;
                deactivate.close();
            }
        }
    }else{
        cout << "List is empty" << endl;
    }
}

void display(){
    cout << "\n\t\t\t\tBankeru DATABASE: " << endl;
    cout << "\n\t\tAccount/s:\t\tName: "<< endl;
    int j = 0, i;
    for(i=0;i<last+1;i++){
        cout << "\t" <<  ++j << ")\t" << info[i].account_number << "\t" << info[i].last_name << ", " << info[i].first_name << endl;
    }

    j = 0;
    cout << "\n\t\tAccounts on hold: " << endl;
    for(i=0;i<last+1;i++){
    string line;
    ifstream inFile("Locked accounts.txt");
    while(inFile >> line){
        if(line == info[i].account_number){
            cout << "\t" <<  ++j << ")\t" << info[i].account_number << "\t" << info[i].last_name << ", " << info[i].first_name << endl;
            break;
        }
    }
    }
}

void save(){
    remove("List of accounts.txt");
    ofstream outFile("List of accounts.txt",ios::app);
    for(int i=0;i<last+1;i++){
        outFile << info[i].account_number << endl;
        string file_name = "Customers\\" + info[i].account_number + ".txt";
        ofstream outFile(file_name);
        outFile << info[i].last_name << "\n" << info[i].first_name << "\n" << info[i].age << "\n" << info[i].birthday << "\n" << info[i].address << "\n" << info[i].contact_num << "\n" << info[i].email << endl;
        outFile.close();

    }

    cout << "\n\t\tThe Database is successfully saved and updated!" << endl;
}
