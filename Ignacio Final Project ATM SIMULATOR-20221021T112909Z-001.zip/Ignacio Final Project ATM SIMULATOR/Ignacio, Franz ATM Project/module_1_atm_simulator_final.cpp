#include<iostream>
#include<windows.h>
#include<fstream>
#include<conio.h>
#include<malloc.h>
#include<time.h>
#include<string>
using namespace std;

typedef struct node{
    string lastname;
    string firstname;
    string age;
    string birthday;
    string address;
    string contact_num;
    string email;

    string acc_num;
    string pin;
    int balance;

    struct node *next;
}LIST;

LIST *L;

void makeNull();
void retrieve();
void save();
void add_account();
string encrypt(string);
string create_acc_num(string);
void insertAcc(string,string,string,string,string,string,string,string,string,int);
void display();
void editAcc();
int menu();
int locate_path(string,string,int);

int last = 0;

int main(){

    makeNull();
    retrieve();
    while(1){
        switch(menu()){
        case 1:system("cls");
            add_account();
            getch();break;
        case 2:system("cls");
            display();
            getch();break;
        case 3:system("cls");
            editAcc();
            getch();break;
        case 4:system("cls");
            save();
            getch();exit(0);
        default:break;
        }
    }

return 0;
}
void makeNull(){L = NULL;}

void retrieve(){
    string acc_num, pin = "dummy";
    int balance;
    ifstream inFile("List of accounts.txt");
    while(inFile >> acc_num >> balance){
        string name = acc_num + ".txt";
        string file = "Customers\\" + name;
        string line[7];
        ifstream read(file);
        int i = 0;
        while(i<7){
            getline(read, line[i]);
            i++;
        }
        insertAcc(line[0],line[1],line[2],line[3],line[4],line[5],line[6],acc_num,pin,balance);
        read.close();
    }
    inFile.close();
}

int menu(){
    system("cls");
    int opt;
    cout << "\n\n\t\tWelcome to Bankeru:\n"<<endl;
    cout << "\t\t[1]\tAdd Account" << endl;
    cout << "\t\t[2]\tDisplay Account/s" << endl;
    cout << "\t\t[3]\tEdit Account" << endl;
    cout << "\t\t[4]\tSave & Exit" << endl;
    cout << "\t\tOption: ";
    cin >> opt;
    return opt;
}

void add_account(){

    string lastn, firstn, age, birthday, address, contact_num, email, acc_num, pin;
    int balance;

    cout << "\n\n\t\tAdd Account: \n" << endl;
    cout << "\t\tLast Name: ";
    getline(cin>>ws, lastn);
    cout << "\t\tFirst Name: ";
    getline(cin>>ws, firstn);
    cout << "\t\tAge: ";
    getline(cin>>ws, age);
    cout << "\t\tBirthday: ";
    getline(cin>>ws, birthday);
    cout << "\t\tAddress: ";
    getline(cin>>ws, address);
    cout << "\t\tContact Number: ";
    getline(cin>>ws,contact_num);
    cout << "\t\tEmail: ";
    getline(cin>>ws,email);

    do{system("cls");
        cout << "\n\n\t\tDeposit: ";
        cin >> balance;
    }while(balance < 500 || balance > 20000);

    srand(time(NULL));
    pin = encrypt(pin);
    acc_num = create_acc_num(acc_num);

    while(locate_path(acc_num,pin,balance)){
        system("cls");
        cout << "\n\n\t\tPlease Insert ATM-Card to proceed...";
    }

    cout << "\n\t\tRegistered Successfully!" << endl;

    insertAcc(lastn,firstn,age,birthday,address,contact_num,email,acc_num,pin,balance);
}

int locate_path(string acc_num, string pin, int balance){

    for(char i = 'D'; i <= 'G'; i++){
        string file = ":\\data.txt";
        string file_path = i + file;
        fstream card(file_path, fstream::in | fstream::out);
        if(card){
            card << acc_num << " " << pin << " " << balance << endl;
            return 0;
        }
        card.close();
    }
    return 1;
}

string encrypt(string pin){
    for(int i=0;i<6;i++){
        pin += to_string((rand() % 9) + 1);
    }
    system("cls");
    cout << "\n\n\t\tYour Temporary pin:  " << pin;
    for(int i=0;i<6;i++){
        pin[i] += 30;
    }
    return pin;
}

string create_acc_num(string acc_num){
    int i = 0;
    acc_num = "Bankeru-" + to_string(6900 + last) + "-";
    while(i<4){
        acc_num += to_string(rand()%9);
        i++;
    }
    cout << "\n\t\tAccount Number: " << acc_num;
    return acc_num;
}

void insertAcc(string lastn, string firstn, string age, string bday, string address, string contact_num, string email, string acc_num, string pin, int balance){

    LIST *p, *q, *n = new LIST;
    p = q = L;

    n->lastname = lastn;
    n->firstname = firstn;
    n->age = age;
    n->birthday = bday;
    n->address = address;
    n->contact_num = contact_num;
    n->email = email;
    n->acc_num = acc_num;
    n->pin = pin;
    n->balance = balance;

    while(p!=NULL){
        q = p;
        p = p->next;
    }

    if(p == L){
        L = n;
    }else{
        q->next = n;
    }

    n->next = p;
    last++;
}

void display(){
    LIST *p;
    p = L;
    int i = 0;
    cout << "\n\t\tBankeru DATABASE: \n" << endl;
    cout << "\t\tAccount/s:\t\tName:" << endl;
    while(p!=NULL){
        cout << "\t\t" << ++i <<") " << p->acc_num << "\t" << p->lastname << ", " << p->firstname << endl;
        p = p->next;
    }
}

void editAcc(){
    display();
    int pos, i = 0;
    cout << "\n\t\tEdit Index: ";
    cin >> pos;
    if(pos<1 || pos>last){
        system("cls");
        editAcc();
    }else{
        system("cls");
        pos -= 1;
        LIST *p;
        p = L;
        while(i!=pos){
            p = p->next;
            i++;
        }
        int choice;
        string repl;

        cout << "\n\n\t\tEdit Account Number: " << p->acc_num << endl;
        cout << "\t\t[1]\t Last Name: " << p->lastname << endl;
        cout << "\t\t[2]\t First Name: " << p->firstname << endl;
        cout << "\t\t[3]\t Age: " << p->age << endl;
        cout << "\t\t[4]\t Birthday: " << p->birthday << endl;
        cout << "\t\t[5]\t Address: " << p->address << endl;
        cout << "\t\t[6]\t Contact Number: " << p->contact_num << endl;
        cout << "\t\t[7]\t Email: " << p->email << endl;
        cout << "\n\t\tEdit Index: ";
        cin >> choice;

        cout << "\t\tReplace with: ";
        getline(cin>>ws,repl);

        switch(choice){
        case 1:p->lastname = repl;break;
        case 2:p->firstname = repl;break;
        case 3:p->age = repl;break;
        case 4:p->birthday = repl;break;
        case 5:p->address = repl;break;
        case 6:p->contact_num = repl;break;
        case 7:p->email = repl;break;
        default:editAcc();
        }
        cout << "\n\n\t\tDatabase updated!" << endl;
    }
}

void save(){
    LIST * p;
    p = L;
    remove("List of accounts.txt");
    while(p!=NULL){

        ofstream List("List of accounts.txt",ios::app);
        string acc_num = p->acc_num;
        List << p->acc_num << " " << p->balance << endl;
        List.close();

        string file = "Customers\\" + acc_num + ".txt";
        ofstream customers(file);
        customers << p->lastname << endl;
        customers << p->firstname << endl;
        customers << p->age << endl;
        customers << p->birthday << endl;
        customers << p->address << endl;
        customers << p->contact_num << endl;
        customers << p->email << endl;
        customers.close();

        p = p->next;
    }
    cout << "\n\n\t\tSuccessfully saved!\n\n" << endl;

}
