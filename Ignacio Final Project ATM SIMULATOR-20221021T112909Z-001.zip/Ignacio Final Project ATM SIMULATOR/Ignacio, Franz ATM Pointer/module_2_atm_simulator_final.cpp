/*Ignacio, Franz Arvae
BS-IT 2C */

#include<iostream>
#include<string>
#include<windows.h>
#include<conio.h>
#include<fstream>
#include<stdlib.h>
#include<string>

using namespace std;

typedef struct fundTransfer{
    string acc_num;
    int funds;
    struct fundTransfer * next;
}FTrans;

typedef struct accounts{
    string acc_num;
    int balance;
    struct accounts * next;
}ACCOUNTS;

typedef struct lockedAccounts{
    string acc_num;
    struct lockedAccounts * next;
}LOCK;

typedef struct profile{
    string acc_num;
    string pin;
    string dpin;
    int balance;

    int error;
    int amount;
    string holder;
    char path;
    int charge_exception;
}N;

FTrans *F;
ACCOUNTS *A;
LOCK *L;
N *n = new N;

void make_null();
void retrieve();
void save();
void insert_account(string,int,int);

void decrypt();
void card_queue(int);
int display_menu();
int check_pin();
int locate_path();
void menu();
int check_balance();
int check_account(string);
void charge_transaction();
void claim_transfer();
int check_if_locked();

void withdraw();
void bal_inq();
void fund_transfer();
void deposit();
void change_pin();

void num_only(int);

int main(){

    make_null();
    retrieve();
    while(1){
        card_queue(0);
        if(check_if_locked() && display_menu()){
            menu();
        }
        save();
        card_queue(1);
    }

return 0;
}
void make_null(){
    F = NULL;
    A = NULL;
    L = NULL;
}

void retrieve(){
    ifstream fundTransfer("Fund Transfer.txt");
    ifstream lockedAccounts("Locked Accounts.txt");
    ifstream accounts("List of accounts.txt");

    string acc_num;
    int funds;
    while(fundTransfer >> acc_num >> funds){
        insert_account(acc_num,funds,1);
    }
    fundTransfer.close();

    while(lockedAccounts >> acc_num){
        insert_account(acc_num,0,2);
    }
    lockedAccounts.close();

    while(accounts >> acc_num >> funds){
        insert_account(acc_num,funds,3);
    }
    accounts.close();
}

void insert_account(string acc_num, int funds, int flag){
    if(flag == 1){
        FTrans *p, *q, *ft = new FTrans;
        p = q = F;
        ft->acc_num = acc_num;
        ft->funds = funds;

        while(p!=NULL){
            q = p;
            p = p->next;
        }
        if(p == F){
            F = ft;
        }else{
            q->next = ft;
        }
        ft->next = p;
    }
    if(flag == 2){
        LOCK *a, *b, *lk = new LOCK;
        a = b = L;
        lk->acc_num = acc_num;
        while(b!=NULL){
            a = b;
            b = b->next;
        }
        if(b == L){
            L = lk;
        }else{
            a->next = lk;
        }
        lk->next = b;

    }
    if(flag == 3){
        ACCOUNTS *m, *n, *info = new ACCOUNTS;
        m = n = A;
        info->acc_num = acc_num;
        info->balance = funds;
        while(n!=NULL){
            m = n;
            n = n->next;
        }
        if(n == A){
            A = info;
        }else{
            m->next = info;
        }

        info->next = n;
    }
}

void decrypt(){
    string pin;
    for(int i=0;i<6;i++){
        pin += n->pin[i] - 30;
    }
    n->dpin = pin;
}

int locate_path(){

    for(char i = 'D'; i <= 'H'; i++){
        string file = ":\\data.txt";
        string file_path = i + file;
            ifstream database(file_path);
            if(database){
                database >> n->acc_num >> n->pin >> n->balance;
                database.close();
                n->path = i;
                return 0;
            }
            database.close();
    }
    return 1;
}

void card_queue(int flag){
    if(flag == 0){
        while(locate_path()){
            system("cls");
            Sleep(1000);
            cout << "\n\n\t\tPlease Insert ATM Card";
            Sleep(1000);
        }
    }

    if(flag == 1){
        while(!locate_path()){
            system("cls");
            Sleep(1000);
            cout << "\n\n\t\tPlease wait for the card to be ejected";
            Sleep(1000);
        }
    }
}

int check_if_locked(){
    LOCK *p;
    p = L;
    while(p!=NULL){
        if(p->acc_num == n->acc_num){
            cout << "\n\n\t\tYour account is temporarily locked" << endl;getch();
            return 0;
        }
    p = p->next;
    }
    return 1;
}

int display_menu(){
    decrypt();
    claim_transfer();
    int i = 0;
    while(i<3){
        system("cls");
        cout << " d.pin: "<< n->dpin << endl;
        cout << "\n\n\t\tWelcome to Bankeruu~" << endl;
        int flag = check_pin();

        if(flag == 1){
            return flag;
        }
        if(flag == 0){
            n->error++;
            cout << "\n\n\t\t\tWrong pin!" << endl;getch();
            if(n->error == 3){
                insert_account(n->acc_num,0,2);
                cout << "\n\n\t\tDue to multiple attempts your account has been locked temporarily...";getch();
                return flag;
            }
        }

        i++;
    }
}

int check_pin(){
    cout << "\n\n\t\t\tInput your 6-digit password: ";
    string pin;
    char holder;

    int i = 0;
    while(i<6){
        holder = getch();
        if(holder==8 && i>=0){
            cout << "\b \b";
            pin.pop_back();
            i--;
        }else{
            if(isdigit(holder)){
                putch('*');
                pin += holder;
                i++;
            }else{
                i--;
            }
        }
    }

    if(pin == n->dpin){
        return 1;
    }else{
        return 0;
    }
}

void save(){

    string file = ":\\data.txt";
    string file_path = n->path + file;
    ofstream cardFile(file_path);
    cardFile << n->acc_num << " " << n->pin << " " << n->balance << endl;
    cardFile.close();

    remove("Fund Transfer.txt");
    remove("Locked Accounts.txt");
    remove("List of accounts.txt");

    ofstream fundTransfer("Fund Transfer.txt");
    ofstream lockedAccounts("Locked Accounts.txt");
    ofstream accounts("List of accounts.txt");

    FTrans *ft;
    ft = F;
    while(ft!=NULL){
        fundTransfer << ft->acc_num << " " << ft->funds << endl;
        ft = ft->next;
    }
    fundTransfer.close();

    LOCK *lk;
    lk = L;
    while(lk!=NULL){
        lockedAccounts << lk->acc_num << endl;
        lk = lk->next;
    }
    lockedAccounts.close();

    ACCOUNTS *info;
    info = A;
    while(info!=NULL){
        if(n->acc_num == info->acc_num){
            info->balance = n->balance;
        }
        accounts << info->acc_num << " " << info->balance << endl;
        info = info->next;
    }
    accounts.close();

}

void menu(){
    n->charge_exception = 0;

    system("cls");
    int choice;
    cout << "\n\n\t\t\t\tWelcome to Banktotan\n\n " << endl;
    cout << "\t\t[1] Withdraw\t\t\t\t[5] Deposit"  << endl;
    cout << "\t\t[2] Balance Inquiry\t\t\t[6] Cancel Transaction"  << endl;
    cout << "\t\t[3] Fund transfer" << endl;
    cout << "\t\t[4] Change Pin "<< endl;

    cout << "\n\n\t\t\t\t\tOption: ";
    cin >> choice;

    switch(choice){
    case 1:system("cls");
        withdraw();
        getch();break;

    case 2:system("cls");
        bal_inq();
        getch();break;

    case 3:system("cls");
        fund_transfer();
        getch();break;

    case 4:system("cls");
        change_pin();
        getch();break;

    case 5:system("cls");
        deposit();
        getch();break;

    case 6:system("cls");
        cout << "\n\n\t\tTransaction Cancelled!" << endl;
        n->charge_exception = 1;
        getch();break;

    default:menu();
    }

    charge_transaction();
}

void withdraw(){
    if(n->balance >= 200){
        cout << "\n\n\t\tWithdraw: ";
        num_only(0);
        int flag = check_balance();
        if(flag == 0){
            n->balance -= n->amount;
            cout << "\n\n\t\tSuccessfully withdrawn Php" << n->amount << " from your account!\nRemaining balance: Php" << n->balance << endl;
        }
    }else{
        cout << "Not enough balance..." << endl;
    }
}

int check_balance(){

    if(n->amount < n->balance && n->balance - n->amount > 100){
        if(n->amount % 100 != 0 && n->amount != 0){
            cout << "\n\t\tNotice: Machine only accepts/gives 100 pesos and higher bills... gomenasai" << endl;
            getch();
            return 1;
        }
        return 0;

    }else{
        cout << "\n\t\tNot enough funds on your account..." << endl;
        cout << "\t\tMaintaining Balance should not be less than P100" << endl;
        getch();
        return 1;
    }

}

void bal_inq(){
    int opt;
    cout << "\n\n\t\tAccount: " << n->acc_num << endl;
    cout << "\t\tBalance: " << n->balance << endl;

    cout << "\n\n\t\tNew Transaction?[1][0] : ";
    cin >> opt;

    if(opt == 1){
        menu();
    }
}

void deposit(){

    int checker = check_account(n->acc_num);
    if(checker == 1){
        cout << "\n\n\t\tAccount not verified..." << endl;
        n->charge_exception = 1;
    }else{
        do{
            system("cls");
            cout << "\n\n\t\tDeposit: ";
            num_only(0);
        }while(n->amount<500 || n->amount>20000 || n->amount % 100 != 0 || checker == 1);

        n->balance+=n->amount;
    }
}

int check_account(string locate){
    ACCOUNTS *p;
    p = A;
    while(p!=NULL){
        if(p->acc_num == locate){
            return 0;
        }
        p = p->next;
    }
    return 1;
}

void fund_transfer(){

    string ft_acc;
    int checker;
    do{ system("cls");
        cout << "\n\n\t\tEnter Bank Account: ";
        getline(cin>>ws, ft_acc);
        checker = check_account(ft_acc);
        if(ft_acc == n->acc_num){
            cout << "\n\t\tYou cannot transfer funds to your own account";
            getch();
        }
    }while(ft_acc == n->acc_num);

    if(checker == 1){
        cout << "\n\n\t\tAccount not found..." << endl;
        n->charge_exception = 1;
    }else{
        int flag;
        do{
            system("cls");
            cout << "\n\n\t\tTransfer Funds to " << ft_acc << endl;
            cout << "\t\tDeposit: ";
            num_only(0);
            flag = check_balance();
        }while(n->amount<500 || n->amount>20000 || n->amount % 100 != 0 || checker == 1 || flag == 1);

        int error = 0;
        while(error < 3 && flag == 0){
            system("cls");
            flag = check_pin();
            if(flag == 0){
                error++;
            }
        }
        if(error != 3){
            FTrans *p;
            p = F;

            while(p!=NULL){
                if(p->acc_num == ft_acc){
                    p->funds += n->amount;
                    cout << "\n\t\tFund successfully transfered to: " << p->acc_num << endl;
                    break;
                }
                p = p->next;
            }
            n->balance -= n->amount;
            insert_account(ft_acc,n->amount,1);
        }else{
            cout << "\n\n\t\tDue to multiple attempts, transaction canceled!";
        }
    }
}

void change_pin(){
    int checker = check_account(n->acc_num);
    if(checker == 1){
        cout << "\n\n\t\tAccount not verified..." << endl;
    }else{
        int error = 0;
        int flag;
        do{
        system("cls");
        cout << n->dpin << endl;
        flag = check_pin();
        error++;
        }while(error != 3 && flag != 1);

        if(error != 3){
            string temp, temp2;
            do{ system("cls");
                cout << "\n\n\t\tEnter new pin: ";
                num_only(1);
                temp = n->holder;
                cout << "\n\n\t\tRe-enter new pin: ";
                num_only(1);
                temp2 = n->holder;
                if(temp != temp2){
                    cout << "\n\n\t\tError: Pin mismatch...";getch();
                }
            }while(temp != temp2);

            for(int i=0;i<6;i++){
                temp[i]+=30;
            }
            n->pin = temp;
        }else{
            cout << "\n\n\t\tMultiple Attempts..." << endl;
            n->charge_exception = 1;
        }
    }

}

void num_only(int flag){
    string amount;
    char holder;

    int i = 0;
    while(i<6){
        holder = getch();
        if(holder==8 && i>=0){
            cout << "\b \b";
            amount.pop_back();
            i--;
        }else if(holder==13){
            break;
        }else{
            if(isdigit(holder)){
                if(flag==0){putch(holder);}
                else{putch('*');}
                amount += holder;
                i++;
            }else{
                i--;
            }
        }
    }
    n->holder = amount;
    n->amount = atoi(amount.c_str());
}

void charge_transaction(){
    int flag = check_account(n->acc_num);

    if(flag == 1 && n->charge_exception == 0){
        n->balance -= 15;
        cout << "\n\n\t\tTransaction Charged" << endl;getch();
    }
}

void claim_transfer(){
    string acc_num;
    int funds;
    int pos = 0;
    ifstream inFile("Fund Transfer.txt");
    while(inFile >> acc_num >> funds){
        if(acc_num == n->acc_num){
            n->balance+=funds;
            cout << "\n\n\t\tYou've received funds!";
            Sleep(2000);
            break;
        }
    pos++;
    }
    inFile.close();

    FTrans *q, *p;
    q = p = F;

    int i = 0;
    while(p!=NULL && p->acc_num != n->acc_num){
        q = p;
        p = p->next;
    }
    if(p == NULL){

    }else{
        if(p==F){
            F = F->next;
        }else{
            q->next = p->next;
        }
    }

    free(p);
}
